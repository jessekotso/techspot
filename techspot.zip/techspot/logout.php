<?php
include 'php/auth.php';
logout();
?>
