<?php
include 'php/db.php'; // Include the database connection
include 'templates/header.php';

try {
    // Fetch all courses for use across multiple sections
    $courses = $pdo->query("SELECT * FROM courses")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $courses = [];
    $error_message = "Error fetching courses: " . $e->getMessage();
}
?>

<div class="container">
    <h1>Training Courses</h1>
    
    <!-- Available Courses Section -->
    <section id="courses">
        <h2>Available Courses</h2>
        <div class="courses-list">
            <?php if (!empty($courses)): ?>
                <?php foreach ($courses as $course): ?>
                    <div class="course-item">
                        <h3><?= htmlspecialchars($course['name']) ?></h3>
                        <p><?= htmlspecialchars($course['description']) ?></p>
                        <p>Duration: <?= htmlspecialchars($course['duration']) ?></p>
                        <a href="course-details.php?id=<?= htmlspecialchars($course['id']) ?>" class="btn">Learn More</a>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No courses available at the moment.</p>
            <?php endif; ?>
        </div>
    </section>

    <!-- Training Schedule Section -->
    <section id="schedule">
        <h2>Training Schedule</h2>
        <div class="schedule-list">
            <?php
            try {
                $schedule = $pdo->query("SELECT * FROM training_schedule")->fetchAll(PDO::FETCH_ASSOC);
                if (!empty($schedule)):
                    foreach ($schedule as $session):
            ?>
                        <div class="schedule-item">
                            <h3><?= htmlspecialchars($session['course_name']) ?></h3>
                            <p>Date: <?= htmlspecialchars($session['date']) ?></p>
                            <p>Time: <?= htmlspecialchars($session['time']) ?></p>
                        </div>
            <?php
                    endforeach;
                else:
                    echo "<p>No scheduled sessions available at the moment.</p>";
                endif;
            } catch (PDOException $e) {
                echo "<p>Error fetching training schedule: " . $e->getMessage() . "</p>";
            }
            ?>
        </div>
    </section>

    <!-- Enrollment Section -->
    <section id="enrollment">
        <h2>Enroll in a Course</h2>
        <form action="enroll.php" method="post">
            <div class="form-group">
                <label for="course">Select Course:</label>
                <select name="course_id" id="course" required>
                    <?php if (!empty($courses)): ?>
                        <?php foreach ($courses as $course): ?>
                            <option value="<?= htmlspecialchars($course['id']) ?>"><?= htmlspecialchars($course['name']) ?></option>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <option value="">No courses available</option>
                    <?php endif; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="name">Your Name:</label>
                <input type="text" name="name" id="name" required>
            </div>
            <div class="form-group">
                <label for="email">Your Email:</label>
                <input type="email" name="email" id="email" required>
            </div>
            <div class="form-group">
                <label for="phone">Your Phone Number:</label>
                <input type="tel" name="phone" id="phone" required>
            </div>
            <div class="form-group">
                <label for="message">Message (Optional):</label>
                <textarea name="message" id="message"></textarea>
            </div>
            <button type="submit" class="btn">Enroll Now</button>
        </form>
    </section>

    <!-- Resources Section -->
    <section id="resources">
        <h2>Resources</h2>
        <div class="resources-list">
            <?php
            try {
                $resources = $pdo->query("SELECT * FROM resources")->fetchAll(PDO::FETCH_ASSOC);
                if (!empty($resources)):
                    foreach ($resources as $resource):
            ?>
                        <div class="resource-item">
                            <h3><?= htmlspecialchars($resource['title']) ?></h3>
                            <p><?= htmlspecialchars($resource['description']) ?></p>
                            <a href="<?= htmlspecialchars($resource['url']) ?>" target="_blank" class="btn">Access Resource</a>
                        </div>
            <?php
                    endforeach;
                else:
                    echo "<p>No resources available at the moment.</p>";
                endif;
            } catch (PDOException $e) {
                echo "<p>Error fetching resources: " . $e->getMessage() . "</p>";
            }
            ?>
        </div>
    </section>
</div>

<?php include 'templates/footer.php'; ?>

<style>
    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
    }

    h1 {
        text-align: center;
        color: #2c3e50;
        margin-bottom: 30px;
    }

    .courses-list, .schedule-list, .resources-list {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
    }

    .course-item, .schedule-item, .resource-item {
        background-color: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        text-align: center;
    }

    h2 {
        font-size: 2rem;
        margin-bottom: 20px;
        color: #34495e;
        text-align: center;
        border-bottom: 2px solid #1abc9c;
        padding-bottom: 10px;
    }

    p {
        font-size: 1rem;
        color: #555;
        margin-bottom: 15px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    label {
        display: block;
        font-weight: bold;
        margin-bottom: 5px;
        color: #2c3e50;
    }

    input[type="text"], input[type="email"], input[type="tel"], select, textarea {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 1rem;
    }

    textarea {
        height: 100px;
    }

    .btn {
        background-color: #1abc9c;
        color: #fff;
        padding: 10px 20px;
        text-decoration: none;
        border-radius: 5px;
        display: inline-block;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #16a085;
    }
</style>
