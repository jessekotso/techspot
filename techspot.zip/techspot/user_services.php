<?php
// Fetch service requests
try {
    $stmt = $pdo->prepare("
        SELECT sr.id, s.name AS service_name, sr.request_date, sr.status
        FROM service_requests sr
        JOIN services s ON sr.service_id = s.id
        WHERE sr.user_id = ?
    ");
    $stmt->execute([$user_id]);
    $service_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Error fetching service requests: " . $e->getMessage();
    exit();
}
?>

<div class="services-section">
    <h2 class="section-title">Service Requests</h2>
    <?php if (!empty($service_requests)): ?>
        <div class="grid-container">
            <?php foreach ($service_requests as $service): ?>
                <div class="card">
                    <div class="card-content">
                        <h3 class="card-title"><?= htmlspecialchars($service['service_name']) ?></h3>
                        <p><strong>Requested on:</strong> <?= htmlspecialchars(date('F j, Y', strtotime($service['request_date']))) ?></p>
                        <p><strong>Status:</strong> <span class="<?= htmlspecialchars($service['status']) ?>"><?= htmlspecialchars(ucfirst($service['status'])) ?></span></p>
                        <a href="service_details.php?id=<?= htmlspecialchars($service['id']) ?>" class="button">View Details</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p>No service requests made yet.</p>
        <a href="services.php" class="button">Request a Service</a>
    <?php endif; ?>
</div>
