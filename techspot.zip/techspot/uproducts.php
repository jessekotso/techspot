<?php
// products.php
include 'php/db.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Fetch available products
$sql_products = "SELECT id, name, description, price, image_url FROM products";
$stmt_products = $pdo->query($sql_products);
$products = $stmt_products->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="products">
    <h2>Available Products</h2>
    <?php if (empty($products)): ?>
        <p>No products available at the moment.</p>
    <?php else: ?>
        <div class="grid-container">
            <?php foreach ($products as $product): ?>
                <div class="grid-item">
                    <h3><?= htmlspecialchars($product['name']) ?></h3>
                    <p><?= htmlspecialchars($product['description']) ?></p>
                    <p><strong>Price:</strong> $<?= htmlspecialchars($product['price']) ?></p>
                    <?php if (!empty($product['image_url'])): ?>
                        <img src="<?= htmlspecialchars($product['image_url']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                    <?php endif; ?>
                    <form method="POST" action="">
                        <input type="hidden" name="product_id" value="<?= htmlspecialchars($product['id']) ?>">
                        <input type="submit" name="buy_product" value="Buy Now">
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<style>
    .products {
        background: #fff;
        padding: 20px;
        margin: 20px 0;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    .grid-container {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        gap: 20px;
    }
    .grid-item {
        background: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    .grid-item img {
        max-width: 200px;
        border-radius: 5px;
    }
</style>
