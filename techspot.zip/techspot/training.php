<?php
session_start();
include 'php/db.php'; // Include the database connection
include 'templates/header.php';

// Fetch all training courses from the database
try {
    $stmt = $pdo->prepare("SELECT * FROM courses");
    $stmt->execute();
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch random courses for the slideshow
    $randomCourses = $pdo->query("SELECT * FROM courses ORDER BY RAND() LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Error fetching courses: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Training Courses | Tech Spot</title>
    <link rel="stylesheet" href="css/styles.css"> <!-- Ensure this points to your main stylesheet -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Global Styles */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .container {
            background-color: #fff;
            width: 85%;
            margin: 50px auto;
            text-align: center;
        }

        h1 {
            color: #2c3e50;
            font-size: 2.5rem;
            margin-bottom: 30px;
        }

        /* Slideshow container */
        .slideshow-container {
            background-color: #fff;
            position: relative;
            max-width: 100%;
            margin: auto;
            overflow: hidden;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        /* Slides */
        .slide {
            
            display: none;
            text-align: center;
            position: relative;
        }

        .slide img {
            width: 100%;
            height: auto;
            border-radius: 10px;
            object-fit: cover;
        }

        /* Caption text */
        .slide-caption {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            padding: 15px 25px;
            border-radius: 8px;
            text-align: center;
            max-width: 80%;
        }

        .slide-caption h3 {
            font-size: 2rem;
            margin-bottom: 10px;
        }

        .slide-caption p {
            font-size: 1.2rem;
            margin-bottom: 15px;
        }

        .slide-caption .btn {
            background-color: #1abc9c;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s, transform 0.3s;
            margin: 5px;
            display: inline-block;
        }

        .slide-caption .btn:hover {
            background-color: #16a085;
            transform: scale(1.05);
        }

        /* Slideshow controls */
        .slideshow-controls {
            position: relative;
            text-align: center;
            margin-top: 20px;
        }

        .prev, .next {
            cursor: pointer;
            position: absolute;
            top: 50%;
            width: auto;
            padding: 16px;
            margin-top: -22px;
            color: white;
            font-weight: bold;
            font-size: 18px;
            transition: 0.6s ease;
            border-radius: 0 3px 3px 0;
            user-select: none;
        }

        .next {
            right: 0;
            border-radius: 3px 0 0 3px;
        }

        .prev {
            left: 0;
        }

        .prev:hover, .next:hover {
            background-color: rgba(0, 0, 0, 0.8);
        }

        /* Dots/bullets/indicators */
        .dots {
            text-align: center;
            padding: 20px;
            background: #f4f4f4;
            border-radius: 10px;
        }

        .dot {
            cursor: pointer;
            height: 15px;
            width: 15px;
            margin: 0 2px;
            background-color: #bbb;
            border-radius: 50%;
            display: inline-block;
            transition: background-color 0.6s ease;
        }

        .active, .dot:hover {
            background-color: #717171;
        }

        /* Courses Grid Styles */
        .grid-container {
            background-color: #fff;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            align-items: stretch;
            margin-top: 50px; /* Add margin to separate from slideshow */
        }

        .card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            text-align: center;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        }

        .card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            transition: transform 0.3s;
        }

        .card:hover img {
            transform: scale(1.05);
        }

        .card-content {
            padding: 20px;
        }

        .card-title {
            font-size: 1.5em;
            margin-bottom: 10px;
            color: #0057ff;
        }

        .card-text {
            font-size: 1em;
            color: #777;
            margin-bottom: 15px;
        }

        .button {
            background-color: #0057ff;
            color: white;
            padding: 12px 24px;
            text-align: center;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 1rem;
            transition: background-color 0.3s;
        }

        .button:hover {
            background-color: #003bb5;
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .grid-container {
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            }
        }

        /* Footer Styles */
        footer {
            background-color: #0057ff;
            color: white;
            padding: 20px 0;
            text-align: center;
            width: 100%;
        }

        .social-icons a {
            color: white;
            margin: 0 10px;
            font-size: 1.2em;
        }
    </style>
</head>

<body>

<div class="container">
    <h1>Explore Our Top Courses</h1>

    <!-- Slideshow Section -->
    <div class="slideshow-container">
        <?php foreach ($randomCourses as $index => $course): 
            // Check if the course has an image, otherwise use a default image
            $imagePath = !empty($course['image']) ? htmlspecialchars($course['image']) : 'home.png';
        ?>
            <div class="slide <?= $index === 0 ? 'active' : '' ?>">
                <img src="img/<?= $imagePath ?>" alt="<?= htmlspecialchars($course['name']) ?>" class="slide-image">
                <div class="slide-caption">
                    <h3><?= htmlspecialchars($course['name']) ?></h3>
                    <p><?= htmlspecialchars($course['description']) ?></p>
                    <a href="course_details.php?id=<?= htmlspecialchars($course['id']) ?>" class="btn">Preview Course</a>
                    <a href="enroll.php?id=<?= htmlspecialchars($course['id']) ?>" class="btn">Enroll Now</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="slideshow-controls">
        <span class="prev">&#10094;</span>
        <span class="next">&#10095;</span>
    </div>
    <div class="dots">
        <?php foreach ($randomCourses as $index => $course): ?>
            <span class="dot" onclick="currentSlide(<?= $index + 1 ?>)"></span>
        <?php endforeach; ?>
    </div>

    <h1 class="section-title">Our Training Courses</h1>

    <!-- Courses Grid -->
    <div class="grid-container">
        <?php foreach ($courses as $course): ?>
            <div class="card">
                <img src="<?= htmlspecialchars($course['course_image']) ?>" alt="<?= htmlspecialchars($course['name']) ?>">
                <div class="card-content">
                    <h3 class="card-title"><?= htmlspecialchars($course['name']) ?></h3>
                    <p class="card-text"><?= htmlspecialchars($course['description']) ?></p>
                    <a href="enroll_course.php?id=<?= htmlspecialchars($course['id']) ?>" class="button">Enroll Now</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<script>
    let slideIndex = 1;
    showSlides(slideIndex);

    function showSlides(n) {
        let i;
        let slides = document.querySelectorAll('.slideshow-container .slide');
        let dots = document.querySelectorAll('.dot');
        if (n > slides.length) {slideIndex = 1}
        if (n < 1) {slideIndex = slides.length}
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = 'none';
        }
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");
        }
        slides[slideIndex - 1].style.display = "block";
        dots[slideIndex - 1].className += " active";
    }

    function plusSlides(n) {
        showSlides(slideIndex += n);
    }

    function currentSlide(n) {
        showSlides(slideIndex = n);
    }

    document.querySelector('.prev').addEventListener('click', () => {
        plusSlides(-1);
    });

    document.querySelector('.next').addEventListener('click', () => {
        plusSlides(1);
    });
</script>

</body>
</html>