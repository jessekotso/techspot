<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'php/db.php'; // Include the database connection

session_start();

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user details
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Check if user data is fetched correctly
    if (!$user) {
        throw new Exception('User not found.');
    }
} catch (PDOException $e) {
    echo "Error fetching user data: " . $e->getMessage();
    exit();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="css/admin.css"> <!-- Make sure to point this to your main stylesheet -->
    <style>
        /* General dashboard styles */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .sidebar {
            width: 220px;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            background-color: #0057ff;
            padding-top: 20px;
        }

        .sidebar h1 {
            color: #fff;
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar nav ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .sidebar nav ul li {
            text-align: center;
            margin: 10px 0;
        }

        .sidebar nav ul li a {
            color: #ffffff;
            text-decoration: none;
            display: block;
            padding: 10px;
            transition: background-color 0.3s;
        }

        .sidebar nav ul li a:hover,
        .sidebar nav ul li a.active {
            background-color: #003bb5;
        }

        .content {
            margin-left: 240px; /* Adjust based on sidebar width */
            padding: 20px;
        }

        .dashboard-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .section-container {
            background-color: white;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .section-title {
            font-size: 1.8em;
            margin-bottom: 10px;
            color: #0057ff;
        }

        .grid-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
        }

        .card {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: transform 0.3s;
            text-align: center;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card img {
            width: 100%;
            height: 150px;
            object-fit: cover;
        }

        .card-content {
            padding: 15px;
        }

        .button {
            background-color: #0057ff;
            color: white;
            padding: 10px 20px;
            text-align: center;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            display: inline-block;
            transition: background-color 0.3s;
        }

        .button:hover {
            background-color: #003bb5;
        }

        .success-message, .error-message {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
        }

        .success-message {
            background-color: #d4edda;
            color: #155724;
        }

        .error-message {
            background-color: #f8d7da;
            color: #721c24;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .sidebar nav ul {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
            }
            .content {
                margin-left: 0;
                padding: 20px;
            }
            .grid-container {
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            }
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h1>User Dashboard</h1>
    <nav>
        <ul>
            <li><a href="user_dashboard.php?page=profile" class="<?= (isset($_GET['page']) && $_GET['page'] == 'profile') ? 'active' : ''; ?>">Profile</a></li>
            <li><a href="user_dashboard.php?page=courses" class="<?= (isset($_GET['page']) && $_GET['page'] == 'courses') ? 'active' : ''; ?>">Enrolled Courses</a></li>
            <li><a href="user_dashboard.php?page=products" class="<?= (isset($_GET['page']) && $_GET['page'] == 'products') ? 'active' : ''; ?>">Purchased Products</a></li>
            <li><a href="user_dashboard.php?page=services" class="<?= (isset($_GET['page']) && $_GET['page'] == 'services') ? 'active' : ''; ?>">Service Requests</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
</div>

<!-- Main Content -->
<div class="content">
    <div class="dashboard-header">
        <h1>Welcome to Your Dashboard, <?= htmlspecialchars($user['first_name']) ?>!</h1>
    </div>

    <?php
    // Load the appropriate section based on the query string parameter
    if (isset($_GET['page'])) {
        switch ($_GET['page']) {
            case 'profile':
                include 'user_profile.php';
                break;
            case 'courses':
                include 'user_courses.php';
                break;
            case 'products':
                include 'user_products.php';
                break;
            case 'services':
                include 'user_services.php';
                break;
            default:
                echo "<div class='section-container'><p>Invalid section selected.</p></div>";
        }
    } else {
        // Default section (Profile)
        include 'user_profile.php';
    }
    ?>
</div>

</body>
</html>
