<?php
// Fetch purchased products
try {
    $stmt = $pdo->prepare("
        SELECT op.id, p.name, p.description, p.product_image, p.price, op.purchase_date
        FROM orders_products op
        JOIN products p ON op.product_id = p.id
        WHERE op.user_id = ?
    ");
    $stmt->execute([$user_id]);
    $purchased_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Error fetching purchased products: " . $e->getMessage();
    exit();
}
?>

<div class="products-section">
    <h2 class="section-title">Purchased Products</h2>
    <?php if (!empty($purchased_products)): ?>
        <div class="grid-container">
            <?php foreach ($purchased_products as $product): ?>
                <div class="card">
                    <img src="<?= htmlspecialchars($product['product_image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                    <div class="card-content">
                        <h3 class="card-title"><?= htmlspecialchars($product['name']) ?></h3>
                        <p class="card-text"><?= htmlspecialchars($product['description']) ?></p>
                        <p><strong>Purchased on:</strong> <?= htmlspecialchars(date('F j, Y', strtotime($product['purchase_date']))) ?></p>
                        <a href="product_details.php?id=<?= htmlspecialchars($product['id']) ?>" class="button">View Product</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p>No products purchased yet.</p>
        <a href="products.php" class="button">Buy a Product</a>
    <?php endif; ?>
</div>
