<?php
// Fetch enrolled courses
try {
    $stmt = $pdo->prepare("
        SELECT ec.id, c.name, c.description, c.course_image, ec.enrollment_date
        FROM enrolled_courses ec
        JOIN courses c ON ec.course_id = c.id
        WHERE ec.user_id = ?
    ");
    $stmt->execute([$user_id]);
    $enrolled_courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Error fetching enrolled courses: " . $e->getMessage();
    exit();
}
?>

<div class="courses-section">
    <h2 class="section-title">Enrolled Courses</h2>
    <?php if (!empty($enrolled_courses)): ?>
        <div class="grid-container">
            <?php foreach ($enrolled_courses as $course): ?>
                <div class="card">
                    <img src="<?= htmlspecialchars($course['course_image']) ?>" alt="<?= htmlspecialchars($course['name']) ?>">
                    <div class="card-content">
                        <h3 class="card-title"><?= htmlspecialchars($course['name']) ?></h3>
                        <p class="card-text"><?= htmlspecialchars($course['description']) ?></p>
                        <p><strong>Enrolled on:</strong> <?= htmlspecialchars(date('F j, Y', strtotime($course['enrollment_date']))) ?></p>
                        <a href="course_details.php?id=<?= htmlspecialchars($course['id']) ?>" class="button">View Course</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p>No courses enrolled yet.</p>
        <a href="courses.php" class="button">Enroll in a Course</a>
    <?php endif; ?>
</div>
