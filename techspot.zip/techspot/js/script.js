document.addEventListener("DOMContentLoaded", function () {
    // Your JS code here
});
